# NFOT Timing Prototype: Pilot Report

**Status:** Completed software/instrumentation pilot  
**Prototype:** `NFOT-Timing_Demo.py`  
**Interpretation:** Feasibility and bookkeeping only; not a test of NFOT's causal hypothesis.

## Purpose

The pilot checked whether the interactive timing prototype could run a simple number-parity task, assign post-response delays, record software timestamps, calculate timing variables, and export trial-level CSV data.

It was not designed or powered to establish a reliable performance effect.

## Pilot configuration

The prototype used three assigned post-response delay conditions:

| Assigned delay | Planned trials |
| ---: | ---: |
| 0.25 s | 4 |
| 1.00 s | 4 |
| 2.00 s | 4 |
| **Total** | **12** |

Trial order was shuffled. The task was a simple even/odd number-parity task.

## Recorded variables

The prototype records trial-level information including response time, assigned delay, achieved post-response delay, delay error, the Write-Back Gap (`L_s`), and correctness. The exact field definitions should be read alongside [DATA_DICTIONARY.md](DATA_DICTIONARY.md).

The prototype's timestamps are software timing measurements around callbacks and widget-update commands. They are **not** direct measurements of physical screen onset.

## Checks completed

The researcher reports that the pilot was run and the CSV consistency checks were completed. The checks described by the prototype include:

- expected total number of trials and condition counts;
- unique trial identifiers;
- finite numeric values;
- arithmetic consistency of the timing fields; and
- the relationship between the recorded interval, response time, and achieved post-response delay.

These checks establish basic data and bookkeeping consistency only. They do not establish that the browser displayed feedback at the recorded instant or that feedback timing changed performance.

## Results and interpretation

This pilot supports the limited conclusion that the prototype and its CSV workflow were exercised and checked.

The pilot does **not** establish:

- a causal effect of feedback delay on accuracy or learning;
- a neural or biological mechanism;
- equivalence between prototype timestamps and historical BCI event markers;
- physical display-onset timing accuracy; or
- generalization to EEG, BCI, or educational settings.

With only 12 trials, estimates of performance differences would be highly uncertain. Also, feedback arrives after the current response, so its delay cannot cause that already-submitted response to become correct or incorrect. A causal study should specify a subsequent-trial or learning outcome if that is the intended effect.

## Recommended next steps

1. Preserve the original pilot CSV unchanged.
2. Keep the script version, run settings, and validation procedure documented.
3. Define the causal hypothesis and primary outcome before running a confirmatory study.
4. Separate assigned delay, achieved post-response delay, response time, and the full interval `L`.
5. If claims depend on actual display onset, validate physical timing with an appropriate method and supervision.
6. Obtain appropriate adult/mentor and ethics review before recruiting participants or collecting confirmatory human-subject data.

## Reproducibility note

This report documents the pilot's purpose and limits. It does not substitute for the CSV, code, or a preregistered protocol. Do not fill in unverified outcome statistics; add them only after independently checking the saved data.
