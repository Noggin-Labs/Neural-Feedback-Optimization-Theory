# NFOT Timing Prototype: Data Dictionary

**Applies to:** `NFOT-Timing_Demo.py` and its trial-level CSV export.  
**Important:** confirm every column against the actual CSV header and the exact script version used for the run. This document describes the fields reported by the current prototype; it is not a substitute for checking the file.

## Timing fields

| Field | Meaning | Units / notes |
| --- | --- | --- |
| `trial_id` | Identifier for a trial | Identifier; should be unique within a run |
| `assigned_delay_s` | Experimentally assigned post-response delay | Seconds; condition assignment, not the measured delay |
| `rt_s` | Response time measured from the prototype's operational stimulus timestamp to its response callback timestamp | Seconds; includes software/callback timing effects |
| `achieved_post_response_delay_s` | Measured interval from response callback handling to the feedback-command timestamp | Seconds; software timing, not physical display-onset timing |
| `delay_error_s` | Difference between achieved post-response delay and assigned delay | Seconds; confirm the sign convention in the script before comparing values |
| `L_s` | Prototype Write-Back Gap: elapsed time from the operational stimulus timestamp to the feedback-command timestamp | Seconds; approximately response time plus achieved post-response delay, subject to timestamp definitions and rounding |
| `correct` | Whether the parity response matched the correct answer | Boolean or 0/1 depending on CSV encoding |

## Timestamp interpretation

The prototype uses a monotonic performance clock for elapsed-time calculations and may also record UTC timestamps. A monotonic clock is suitable for measuring intervals within a run; UTC values are useful for wall-clock logging. Do not subtract timestamps from different clock systems.

The prototype's `t0` is measured immediately before requesting the stimulus widget update. Its response timestamp is taken when the Python callback begins handling the response. Its `t_fb` is measured immediately before requesting the feedback widget update.

These are software events. They do not directly measure when a stimulus or feedback physically appears on the display.

## Important distinction: `L_s` is not just the assigned delay

The prototype's Write-Back Gap includes both response time and the post-response interval. In simplified form:

`L_s ≈ rt_s + achieved_post_response_delay_s`

Consequently:

- `assigned_delay_s` is the randomized condition;
- `achieved_post_response_delay_s` checks implementation of that condition;
- `rt_s` reflects task response timing; and
- `L_s` combines the pre-response and post-response intervals.

Do not interpret an association involving `L_s` as an isolated causal effect of feedback delay.

## Historical BCI data are different

The historical analysis defines the interval from the `StimulusBegin` event to the rising edge of `DisplayResults`. Those are recorded BCI event markers, not the same software callbacks used in the interactive demo. Keep the two measurement definitions separate in documentation and analysis.

## Validation checklist

For each CSV export, verify:

- column names match the script version;
- the expected number of rows and condition counts are present;
- trial identifiers are unique within the run;
- numeric timing fields are finite and use seconds;
- delay-error arithmetic matches the documented sign convention;
- `L_s` agrees with its component intervals within expected timestamp precision; and
- missing or invalid rows are documented rather than silently discarded.

Passing these checks verifies data consistency, not physical display timing, a causal performance effect, or a biological mechanism.
