# NFOT Research Status

**Last updated:** 2026-10-17  
**Project:** Neural Feedback Optimization Theory (NFOT), Version 5 research line

This page separates completed work from future validation. Status labels describe the work documented in this repository; they do not imply independent verification.

## Completed or reported complete

- **Historical BCI analysis:** V5 reports an observational analysis of 444 trials from 15 participants in bigP3BCI Study M.
- **Event reconstruction:** the README reports target-selection reconstruction checks against 4,192 of 4,192 applicable events.
- **Timing prototype:** `NFOT-Timing_Demo.py` implements a simple parity task with randomized post-response delay conditions and trial-level CSV export.
- **Pilot run:** a 12-trial pilot using assigned delays of 0.25 s, 1.00 s, and 2.00 s (four trials per condition) is reported as completed.
- **CSV consistency checks:** the researcher reports completing the prototype's bookkeeping/consistency checks.

See [PILOT_REPORT.md](PILOT_REPORT.md) for the pilot's scope and limitations.

## Outstanding

- **Protocol finalization:** specify the confirmatory hypothesis, primary outcome, design, sample-size rationale, exclusions, and statistical model before collecting confirmatory data.
- **Causal validation:** the historical analysis is observational and does not establish that manipulating feedback delay changes performance.
- **Physical timing validation:** the prototype records software timestamps around callback and widget-update events, not direct physical display onset.
- **Independent replication:** test the findings using an independent dataset or study.
- **Biological mechanism:** no neural mechanism is established by the current evidence; the prototype does not record EEG.

## Interpretation guardrails

1. Association is not causation.
2. Predictive improvement is not proof of a mechanism.
3. The Write-Back Gap is an operational event interval, not automatically a neural variable.
4. The prototype's timing definition differs from the historical BCI event-marker definition.
5. A 12-trial instrumentation pilot is not evidence of a reliable performance effect.
6. Future null or contradictory results must be reported and may require revising or rejecting the hypothesis.

## Next milestone

Finalize the prospective protocol and have it reviewed before running a confirmatory study. Any human-participant study must follow the appropriate adult/mentor guidance, consent, privacy, and ethics-review requirements.

For the primary repository overview and V5 results, see [README.md](../README.md).
