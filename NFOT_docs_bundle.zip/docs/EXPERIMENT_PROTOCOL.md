# NFOT Prospective Experiment Protocol

**Status: Draft for planning only — not preregistered and not approved for participant recruitment.**

This document is a protocol scaffold for a future controlled study. Fields marked **to be specified** must be settled before confirmatory data collection. The current software pilot is not the confirmatory experiment.

## 1. Research question

Does experimentally assigned post-response feedback delay affect performance on subsequent trials or learning over time in a repeated task?

This is a behavioral question about delayed feedback in the specified task. A simple parity-task experiment would not, by itself, establish a neural mechanism or validate a BCI-specific claim.

## 2. Hypothesis

**Primary hypothesis — to be finalized before data collection:** the delay assigned to a trial affects a prespecified measure of performance on later trials or across the task.

The direction and size of the predicted effect must be stated before confirmatory analysis. Do not choose the hypothesis after inspecting outcome data.

A separate hypothesis may test whether trial-level timing-distribution features improve prediction beyond a mean-timing measure. If pursued, specify the feature, comparison model, and evaluation procedure in advance.

## 3. Design

The existing prototype uses assigned post-response delays of 0.25 s, 1.00 s, and 2.00 s. These are candidate conditions, not a finalized confirmatory design.

Before data collection, specify:

- task instructions and stimulus-generation rules;
- whether participants receive correctness feedback on every trial;
- the randomized assignment method and allocation balance;
- number of trials per participant and number of participants;
- handling of practice trials, breaks, interruptions, and missing trials;
- the primary outcome and the time window over which it is measured; and
- the sample-size rationale or power analysis.

The sample size is **to be determined**. Do not treat the 12-trial pilot as a sample-size justification.

## 4. Timing definitions

Keep these variables distinct:

- **Assigned delay:** the delay condition selected by the experiment.
- **Response time (`rt_s`):** the measured time from the prototype's operational stimulus timestamp to its response callback timestamp.
- **Achieved post-response delay:** the measured interval from the response callback to the software's feedback-command timestamp.
- **Write-Back Gap (`L_s`):** the prototype's measured interval from its operational stimulus timestamp to its feedback-command timestamp.

In the current prototype, `L_s` combines response time and achieved post-response delay. Therefore, an association between `L_s` and an outcome cannot automatically be attributed to the assigned delay alone.

The historical BCI analysis uses dataset event markers (`StimulusBegin` and the rising edge of `DisplayResults`). Those operational endpoints differ from the prototype's software timestamps and must not be described as physically identical without validation.

## 5. Outcomes and analysis plan

**Primary outcome: to be specified before data collection.** Because feedback is delivered after the response, the correctness of that already-submitted response is not an appropriate outcome for a causal effect of its later feedback delay. Possible behavioral outcomes include accuracy on the next trial or a prespecified learning/performance measure across later trials.

Before collecting confirmatory data, specify:

1. the single primary outcome and its operational definition;
2. the primary contrast between assigned conditions;
3. the statistical model, including participant-level dependence and trial order;
4. treatment of missing, interrupted, or invalid trials;
5. effect-size estimate and uncertainty interval to report;
6. any secondary or exploratory analyses; and
7. how multiple comparisons and deviations will be handled.

Analyze the randomized **assigned condition** as the primary causal comparison. Report achieved timing as an implementation check and secondary analysis; do not silently replace assignment with achieved delay, since achieved delay may reflect other factors.

## 6. Timing verification

The current prototype records software timestamps around callback handling and widget-update requests. It does not directly measure physical display onset.

If conclusions depend on actual on-screen timing, define and validate a physical timing measurement method before the study. Document device, browser, refresh rate, timestamp source, measurement procedure, calibration, and timing error. Do not claim physical timing accuracy from software timestamps alone.

## 7. Data management and reproducibility

- Preserve raw exports unchanged.
- Record code version, settings, date of each run, and any deviations.
- Keep a data dictionary for every exported field.
- Use participant codes rather than names in research data.
- Do not commit sensitive or identifiable participant data to a public repository.
- Document all exclusions and cleaning decisions.
- Keep analysis code and the final protocol version with the research record.

## 8. Ethics and participant protection

Before recruiting participants or collecting confirmatory human-subject data, obtain appropriate guidance from a responsible adult research mentor and the relevant school, institutional, or ethics-review process. Participation should be voluntary, privacy should be protected, and procedures should be age-appropriate. Do not collect data from others until the required permissions and safeguards are in place.

## 9. Decision criteria and falsifiability

Specify in advance what result would support the hypothesis, what result would be inconclusive, and what result would count against it. Report null and contradictory results as well as positive findings. A result from a simple behavioral task should not be generalized to neural mechanisms or BCI performance without a separate, appropriate validation study.

## 10. Current status

The software timing pilot and its bookkeeping checks are reported as completed. This protocol remains a planning document. It is not a preregistration, and no causal result should be claimed until the design is finalized and the study is conducted and analyzed as specified.
